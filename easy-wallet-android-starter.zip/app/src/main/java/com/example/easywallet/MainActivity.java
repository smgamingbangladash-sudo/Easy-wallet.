package com.example.easywallet;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.nfc.NfcAdapter;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private LinearLayout root, docsList;
    private EditText nameInput, phoneInput, whatsappInput, facebookInput, instagramInput, addressInput, linkInput;
    private TextView nfcStatus;
    private static final int PICK_DOCUMENT = 41;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("wallet", MODE_PRIVATE);
        buildUi();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private TextView text(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(0xff172033); t.setPadding(0, dp(6), 0, dp(6)); return t;
    }
    private EditText edit(String hint, String key) {
        EditText e = new EditText(this); e.setSingleLine(false); e.setHint(hint);
        e.setText(prefs.getString(key, "")); e.setTextSize(15);
        e.setPadding(dp(12), dp(8), dp(12), dp(8));
        e.setBackgroundColor(0xfff0f3f8);
        return e;
    }
    private Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label);
        b.setOnClickListener(v -> action.run()); return b;
    }
    private void section(String title) { root.addView(text(title, 19)); }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(24)); root.setBackgroundColor(0xfffafbff);
        scroll.addView(root); setContentView(scroll);

        TextView heading = text("EASY WALLET", 27); heading.setTextColor(0xff163b72);
        heading.setGravity(Gravity.CENTER); root.addView(heading);
        TextView sub = text("Your documents • business card • quick link", 13);
        sub.setGravity(Gravity.CENTER); root.addView(sub);

        section("1. Business Card");
        nameInput = edit("Your name", "name"); root.addView(nameInput);
        phoneInput = edit("Phone number", "phone"); root.addView(phoneInput);
        whatsappInput = edit("WhatsApp number or link", "whatsapp"); root.addView(whatsappInput);
        facebookInput = edit("Facebook link", "facebook"); root.addView(facebookInput);
        instagramInput = edit("Instagram link", "instagram"); root.addView(instagramInput);
        addressInput = edit("Address", "address"); root.addView(addressInput);
        root.addView(button("Save Business Card", this::saveBusinessCard));
        root.addView(button("Share Business Card", this::shareBusinessCard));

        section("2. Document Vault (PDF / files)");
        root.addView(text("Add passport, NID, Iqama, driving licence or other files. Files are stored privately on this phone.", 13));
        root.addView(button("Add a document", () -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/pdf", "image/*"});
            startActivityForResult(i, PICK_DOCUMENT);
        }));
        docsList = new LinearLayout(this); docsList.setOrientation(LinearLayout.VERTICAL);
        root.addView(docsList); renderDocs();

        section("3. Smart NFC Link");
        root.addView(text("Save a web link, then share it. On many phones, the recipient must tap the link or scan a QR code; an app cannot force another phone to open a page.", 13));
        linkInput = edit("https://example.com", "quick_link"); root.addView(linkInput);
        root.addView(button("Save / Update Link", () -> {
            String link = linkInput.getText().toString().trim();
            if (!link.matches("https?://.+")) { toast("Enter a full link starting with https:// or http://"); return; }
            prefs.edit().putString("quick_link", link).apply(); toast("Link saved on this phone");
        }));
        root.addView(button("Share Saved Link", this::shareSavedLink));

        section("4. NFC availability");
        boolean hasNfc = getPackageManager().hasSystemFeature("android.hardware.nfc");
        nfcStatus = text(hasNfc ? "This phone has NFC hardware. Direct phone-to-phone app transfer is not supported consistently across Android/iPhone; use Share or QR-compatible fallback." :
                "NFC hardware was not detected. Use the Share button or a QR-compatible method.", 13);
        root.addView(nfcStatus);
        root.addView(button("Check NFC setting", () -> {
            NfcAdapter adapter = NfcAdapter.getDefaultAdapter(this);
            if (adapter == null) toast("This phone does not have NFC.");
            else if (!adapter.isEnabled()) startActivity(new Intent(android.provider.Settings.ACTION_NFC_SETTINGS));
            else toast("NFC is enabled. This starter app shares links using Android Share.");
        }));

        section("Privacy note");
        root.addView(text("This is a starter build. Documents stay in this app's private storage, but this first version does not yet include encrypted cloud backup, biometric lock, payment-card emulation, government-ID validation, or real NFC phone-to-phone transfer. Do not store bank PINs, CVVs or highly sensitive passwords in this prototype.", 12));
    }

    private void saveBusinessCard() {
        prefs.edit()
            .putString("name", nameInput.getText().toString())
            .putString("phone", phoneInput.getText().toString())
            .putString("whatsapp", whatsappInput.getText().toString())
            .putString("facebook", facebookInput.getText().toString())
            .putString("instagram", instagramInput.getText().toString())
            .putString("address", addressInput.getText().toString()).apply();
        toast("Business card saved");
    }
    private String businessCardText() {
        return "Business Card\\nName: " + nameInput.getText() + "\\nPhone: " + phoneInput.getText()
            + "\\nWhatsApp: " + whatsappInput.getText() + "\\nFacebook: " + facebookInput.getText()
            + "\\nInstagram: " + instagramInput.getText() + "\\nAddress: " + addressInput.getText();
    }
    private void shareBusinessCard() {
        saveBusinessCard();
        shareText("Easy Wallet Business Card", businessCardText());
    }
    private void shareSavedLink() {
        String link = prefs.getString("quick_link", "").trim();
        if (link.isEmpty()) { toast("Save a link first"); return; }
        shareText("Easy Wallet link", link);
    }
    private void shareText(String title, String body) {
        Intent send = new Intent(Intent.ACTION_SEND); send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, body);
        startActivity(Intent.createChooser(send, title));
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_DOCUMENT && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                String name = "document_" + System.currentTimeMillis() + getExtension(uri);
                InputStream in = getContentResolver().openInputStream(uri);
                File out = new File(getFilesDir(), name);
                FileOutputStream os = new FileOutputStream(out);
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                in.close(); os.close();
                Set<String> docs = new HashSet<>(prefs.getStringSet("docs", new HashSet<>()));
                docs.add(name); prefs.edit().putStringSet("docs", docs).apply();
                renderDocs(); toast("Document saved privately");
            } catch (Exception e) { toast("Could not save file: " + e.getMessage()); }
        }
    }
    private String getExtension(Uri uri) {
        String type = getContentResolver().getType(uri);
        if ("application/pdf".equals(type)) return ".pdf";
        if (type != null && type.startsWith("image/")) return ".image";
        return ".file";
    }
    private void renderDocs() {
        if (docsList == null) return;
        docsList.removeAllViews();
        for (String file : prefs.getStringSet("docs", new HashSet<>())) {
            TextView item = text("• " + file, 13);
            docsList.addView(item);
        }
        if (docsList.getChildCount() == 0) docsList.addView(text("No documents added yet.", 13));
    }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
